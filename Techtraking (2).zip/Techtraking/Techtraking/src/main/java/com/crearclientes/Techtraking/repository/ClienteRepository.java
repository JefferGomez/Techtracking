package com.crearclientes.Techtraking.repository;

public class ClienteRepository {
}
