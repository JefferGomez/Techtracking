package com.crearclientes.Techtraking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechtrakingApplicationTests {

	@Test
	void contextLoads() {
	}

}
