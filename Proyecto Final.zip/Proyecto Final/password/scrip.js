document.getElementById('Recoveryfrom').addEventListener('submit', function(e) {
     e.preventDefault();
     const username = document.getElementById('Correo Electrónico').value.trim();
      if (correoElectronico  === "admin") {
        alert("Correo enviado");
      }else {
    alert("Credenciales incorrectas. Intenta de nuevo.");
  }

    

});

