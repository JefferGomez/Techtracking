const users = [
  {
    "name": "Alice Smith",
    "email": "alice.smith@example.com",
    "role": "admin",
    "status": "active",
    "date_joined": "2023-10-26"
  },
  {
    "name": "Bob Johnson",
    "email": "bob.johnson@example.com",
    "role": "tecnico",
    "status": "active",
    "date_joined": "2023-10-25"
  },
  {
    "name": "Charlie Brown",
    "email": "charlie.b@example.com",
    "role": "almacenista",
    "status": "inactive",
    "date_joined": "2023-10-24"
  },
  {
    "name": "Diana Prince",
    "email": "diana.p@example.com",
    "role": "admin",
    "status": "active",
    "date_joined": "2023-10-23"
  }
];

function renderTable(data) {
  const tbody = document.getElementById("userBody");
  tbody.innerHTML = "";
  data.forEach(user => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${user.name}</td>
      <td>${user.email}</td>
      <td>${user.role}</td>
      <td class="status ${user.status.toLowerCase()}">${user.status.charAt(0).toUpperCase() + user.status.slice(1)}</td>
      <td>${user.date_joined}</td>
      <td>...</td>
    `;
    tbody.appendChild(tr);
  });

  document.getElementById("totalUsers").textContent = data.length;
}

document.getElementById("search").addEventListener("input", function(e) {
  const searchValue = e.target.value.toLowerCase();
  const filtered = users.filter(user =>
    user.name.toLowerCase().includes(searchValue) ||
    user.email.toLowerCase().includes(searchValue) ||
    user.role.toLowerCase().includes(searchValue)
  );
  renderTable(filtered);
});

renderTable(users);