document.getElementById('deleteForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const userId = document.getElementById('userId').value;
  const messageDiv = document.getElementById('message');

  if (userId.trim() !== '') {
    messageDiv.textContent = `✅ Usuario con ID/email "${userId}" ha sido eliminado.`;
    messageDiv.style.color = 'green';
  } else {
    messageDiv.textContent = '❌ Por favor, ingrese un ID o correo válido.';
    messageDiv.style.color = 'red';
  }
});