document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('changePasswordBtn').addEventListener('click', function () {
    // Redirige a la página para cambiar la contraseña
    window.location.href = 'reset-password.html'; // Cambia esta ruta si es diferente
  });
});
