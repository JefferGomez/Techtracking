document.getElementById('userForm').addEventListener('submit', function (e) {
  e.preventDefault();
  alert('Usuario creado exitosamente.');
});